Sample of UsageStatsManager.

This repository is no longer maintained.
